# Zingora Android APK build

This wraps the provided Zingora web app in an Android WebView app. It is an unsigned-for-store debug APK build (Android signs debug APKs automatically), suitable for sideloading on a personal Android phone.

## Build APK using GitHub Actions (no Android SDK required on your computer)
1. Create a new GitHub repository and upload the contents of this folder.
2. Open **Actions** and run **Build Zingora APK** (or push to `main`).
3. Open the completed workflow run and download the `zingora-apk` artifact.
4. Extract the artifact ZIP; it contains `app-debug.apk`.
5. Send `app-debug.apk` to your Android phone, tap it, and allow installation from that source if Android asks.

This project has not yet been compiled or tested on a physical Android device in this environment. The output is a debug APK, not a Play Store release.
